
<?php $__env->startSection('page-tab'); ?>
    Manage Citizenship
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="main" class="main" style="padding-top: 0vh;">
      <div class="pagetitle">
          <h1>Citizenship</h1>
          <nav>
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item active"><a> Manage Citizenship</a></li>
          </ol>
          </nav>
      </div>
    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
    <p><?php echo e($message); ?></p>
    </div>
    <?php endif; ?>
    <div class="col-md-2 col-lg-2 col-sm-12" style="float: right; padding-bottom:10px"> 
    <input type="search" name="search"  class="form-control" placeholder="search">
    </div>
    <div class="row justify-content-center" style="border: 1px solid rgb(122, 122, 122); width:100%;padding:10px">
    <div class="col-xs-8 col-sm-8 col-md-10">
    <div class="card-body">
    <table class="table table-borderless datatable">
    <tr>
    <th>S.No</th>
    <th>Citizenship</th>
    <th width="280px">Action</th>
    </tr>
    <?php $__currentLoopData = $citizenships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($division->id); ?></td>
    <td><?php echo e($division->name); ?></td>

    <td>
    <form action="" method="POST">

    <a class="btn btn-primary" href="">Edit</a>

    </form>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
    </div>
    <div class="d-flex justify-content-between align-items-center" style=" margin: auto;
    width: 50%;">
    <button type="button" class="btn btn-warning">Previous</button>
    <button type="button" class="btn btn-warning">Next</button>
    </div>
    <?php echo e($citizenships->links()); ?>    
</section>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/generalsetup/citizenship/index.blade.php ENDPATH**/ ?>