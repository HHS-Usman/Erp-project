
<?php $__env->startSection('page-tab'); ?>
    Create Designation
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="maincontainer">
  <section id="main" class="main" style="padding-top: 0vh;">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <br><br>
        <div class="form-container">
            <link rel="stylesheet" href="/as/style.css">
            <h1>Manage Designation</h1>
            <nav>
            <ol style="color:white;">
                <li class="breadcrumb-item">Home</li>
                <li class="breadcrumb-item">Manage Designation</li>
            </ol>
            </nav>
            <form action="<?php echo e(route('designation.store')); ?>" method="POST">           
              <?php echo csrf_field(); ?>
                <div class="row justify-content-center">
                    <div class="col-xs-6 col-sm-6 col-md-6">
                        <div class="form-group">
                            <strong>Designation</strong>
                            <input type="text" name="designation" id="designation" class="form-control" placeholder="designation">
                        </div>
                        <div class="form-group">
                            <strong>Designation Code</strong>
                            <input type="text" name="designation_code" id="designation_code" class="form-control" placeholder="designation Code">
                        </div>
                        <div class="form-group">
                            <strong>Details</strong>
                            <input type="text" name="detail" id="detail" class="form-control" placeholder="Detail">
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
            <footer id="footer" class="footer justify-content-center">
                <div class="copyright col-4">
                &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
                </div>
                <div class="copyright col-4">
                version here
                </div>
                <div class="credits col-4">
                Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                </div>
            </footer>
            <!-- End Footer -->
        </div>
  </section>
</div>      

<?php $__env->stopSection(); ?>    
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/organizationsetup/designation/create.blade.php ENDPATH**/ ?>