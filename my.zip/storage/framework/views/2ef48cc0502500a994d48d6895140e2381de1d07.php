
<?php $__env->startSection('page-tab'); ?>
    Create Leaving Reason
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

  <section id="main" class="main" style="padding-top: 0vh;">
    <div class="pagetitle">
        <h1>Add Leave Reason </h1>
        <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item active"><a href="<?php echo e(route('leavereson.create')); ?>">Create </a></li>
        </ol>
        </nav>
    </div>
  
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="form-container">
            <link rel="stylesheet" href="/as/style.css">
            <form action="<?php echo e(route('leavereson.store')); ?>" method="POST">        
      <?php echo csrf_field(); ?>
      <div class="row justify-content-center">
        <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <strong>Leaving Reason</strong>
                    <input type="text" name="leavingreason" class="form-control" placeholder="Leaving Reason">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
     </form>
        </div>
  </section>  

<?php $__env->stopSection(); ?>    
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/organizationsetup/leavereson/create.blade.php ENDPATH**/ ?>