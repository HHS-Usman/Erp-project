
<?php $__env->startSection('page-tab'); ?>
    Create Gazeted Holidays
<?php $__env->stopSection(); ?>    
<?php $__env->startSection('content'); ?>

  <section id="main" class="main" style="padding-top: 0vh;">
        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
            <div class="pagetitle" style="margin-left: 20px;">
                <h1>Create Week Off Day</h1>
                <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                    <li class="breadcrumb-item active"><a> Create Week Off Day</a></li>
                </ol>
                </nav>
            </div>
            <br><br>
            
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <head>
                <style>
                .selected{
                  cursor: pointer;
                  background-color: #157EFB !important;
                  color: #FFF;
                  border-radius: 0.25rem;
                }
              </style>
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
                          integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
                          crossorigin="anonymous">
                  </script>
                  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
                          integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
                          crossorigin="anonymous"></script>
                  <!-- Project Files -->
                  <link rel="stylesheet" href="/as/jquery.bootstrap.year.calendar.css">
                  <script src="/as/jquery.gazetedhldy.js"></script>
                  

              </head>
              <div class="">
                  <div class="container">
                      <div class="calendar" id="calendar"></div>   
                  </div>
                </div>
                <div class="row " style="">
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                  <?php endif; ?>
                  <form action="<?php echo e(route('gazetedholiday.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?> 
                    <div class="card-body col-xs-12 col-sm-12 col-md-12 text-center">  
                      <table class="table table-bordered datatable " style="">
                        <thead>
                          <tr >
                            <th scope="col">S.No</th>
                            <th scope="col">Year</th>
                            <th scope="col">Month</th>
                            <th scope="col">Date</th>
                            <th scope="col">Day</th>
                            <th scope="col">EventType</th>
                            <th scope="col">Applied To Country</th>
                            <th scope="col">State/Province</th>
                            <th scope="col">religion</th>
                            <th scope="col">Group</th>
                            <th scope="col">Remove</th>
                          </tr>
    
                        </thead>
                        
                          <tbody id="my_test" class="card-body col-xs-12 col-sm-12 col-md-12 text-center">
                          
    
                          </tbody>
                          
                      
                      </table>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                  </form> 
               </div>  
              </div>  
                <script>

                    $('.calendar').calendar({
                        startFromSunday: true,
                
                    });
                   
                </script>
            </div>
        
        
        <br><br><br>
        <br>
        <br>
        <div><br> </div>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
                integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
                crossorigin="anonymous">
        </script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
                integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
                crossorigin="anonymous"></script>
        <!-- Project Files -->
        <link rel="stylesheet" href="/as/jquery.bootstrap.year.calendar.css">
        <script src="/as/jquery.gazetedhldy.js"></script>
  </section> 

<?php $__env->stopSection(); ?>    
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/organizationsetup/gazetedholiday/create.blade.php ENDPATH**/ ?>