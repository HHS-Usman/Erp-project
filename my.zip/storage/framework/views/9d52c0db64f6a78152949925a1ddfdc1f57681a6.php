<form action="<?php echo e(route('monthlydaywise.store')); ?>">
                <?php echo csrf_field(); ?> 
                <div class="card-body col-xs-12 col-sm-12 col-md-12 text-center">  
                  <table class="table table-bordered datatable " style="">
                    <thead>
                      <tr >
                        <th scope="col">Month</th>
                        <th scope="col">Date</th>
                        <th scope="col">Day</th>
                        <th scope="col">EventType</th>
                        <th scope="col">Applied To Country</th>
                        <th scope="col">State/Province</th>
                        <th scope="col">religion</th>
                        <th scope="col">Group</th>
                        <th scope="col">Remove</th>
                      </tr>

                    </thead>
                    
                      <tbody id="my_test">
                      
 
                      </tbody>
                      
                  
                  </table>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
               </form> 
              </div>  <?php /**PATH C:\xampp\htdocs\erp\resources\views/organizationsetup/weekoffday/monthlycalendar.blade.php ENDPATH**/ ?>