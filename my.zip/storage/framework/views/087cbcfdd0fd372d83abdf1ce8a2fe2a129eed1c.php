
<?php $__env->startSection('page-tab'); ?>
    Create Event
<?php $__env->stopSection(); ?>    
<?php $__env->startSection('content'); ?>

  <section id="main" class="main" style="padding-top: 0vh;">
        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
            <div class="pagetitle" style="margin-left: 20px;">
                <h1>Create Event</h1>
                <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                    <li class="breadcrumb-item active"><a> Create Event</a></li>
                </ol>
                </nav>
            </div>
            <br><br><br>
            <form action="<?php echo e(route('event.store')); ?>" method="POST">        
                <?php echo csrf_field(); ?>
                    <div class="row justify-content-center">
                        <div class="col-xs-6 col-sm-6 col-md-6">
                            <div class="form-group">
                                <strong>Event Code</strong>
                                <input type="text" name="event_code" id="event_code" class="form-control" placeholder="Event Code">
                            </div>
                            <div class="form-group">
                                <strong>Event<span style="color:#DC3545">*</span></strong>
                                <input type="text" name="event" id="event" class="form-control" placeholder="Event" required>
                            </div>
                            <div class="form-group">
                                <strong>Details</strong>
                                <input type="text" name="detail" id="detail" class="form-control" placeholder="Detail">
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="1"name="is_active" id="is_active" checked>
                                Active
                                </label>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
            </form>
        </div>
        <br><br><br>
        <br>
        <br>
        <div><br> </div>
        
  </section> 

<?php $__env->stopSection(); ?>    
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/generalsetup/event/create.blade.php ENDPATH**/ ?>