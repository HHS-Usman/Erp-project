

<?php $__env->startSection('page-tab'); ?>
    Manage Employee Job Status
<?php $__env->stopSection(); ?>    
<?php $__env->startSection('content'); ?>
 

  
    <section id="main" class="main" style="padding-top: 0vh;">
        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
            
      <div class="pagetitle" style="margin-left: 20px;">
          <h1>Manage Employee Job Status</h1>
          <nav>
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item active"><a> Manage Employee Job Status</a></li>
          </ol>
          </nav>
      </div>
                  
                    
      <div style="background-color: lightgray;opacity: 0.9; height='20px'; ">
        <ul class="nav nav-tabs" id="myTabs">
          <li class="nav-item">
            <a class="nav-link " data-bs-toggle="tab"></a>
          </li>
        </ul>
      </div>
      <div style=" left:0px; top:170px;z-index: -1; width: 100%;">
        <div class="tab-content" id="myTabContent">
          
                          
                          <!-- Tab content will be dynamically added here -->
                        </div>
                      </div>
                    
                      
                                                  
                
                
                 
              
              <div class="row justify-content-center" >
                <div class="card-body">  
                  <table class="table table-border datatable " style="border: 1px solid black">
                    <thead>
                      <tr >
                        <th scope="col">S.no</th>
                        <th scope="col">EmpJbst_id</th>
                        <th scope="col">Employee Job Status</th>
                        <th scope="col">Employee Job Status Code</th>
                        <th scope="col">Detail</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $employeejobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employeejob =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th ><?php echo e($employeejob + 1); ?></a></th>
                        <th ><?php echo e($item->id); ?></a></th>
                        <td><?php echo e($item->employeejobstatus); ?></td>
                        <td><a  class="datatable-sorter"></a><?php echo e($item->employeejobstatus_code); ?></td>
                        <td><?php echo e($item ->detail); ?></td>
                        <td><?php if($item->is_active): ?>
                                <p>Active</p>
                            <?php else: ?>
                                <p>INActive</p>
                            <?php endif; ?>
                        </td>
                        <td><form action="" method="POST">
                          <a class="btn btn-info" href="">Show</a>
                          <a class="btn btn-primary" href="">Edit</a>
                          
                          <button  class="btn btn-danger">Delete</button>
                      </form></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                      
                    </tbody>
                  </table>
                </div>  
              </div>
              
                
              
          
              
           
              <!-- End Recent Sales -->
            
                <script src="/asset/vendor/apexcharts/apexcharts.min.js"></script>
                <script src="/asset/vendor/chart.js/chart.umd.js"></script>
                <script src="/asset/vendor/echarts/echarts.min.js"></script>
                <script src="/asset/vendor/quill/quill.min.js"></script>
                <script src="/asset/vendor/simple-datatables/simple-datatables.js"></script>
                <script src="/asset/vendor/tinymce/tinymce.min.js"></script>
                <script src="/asset/vendor/php-email-form/validate.js"></script>
                <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
                <script src="/asset/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

                <!-- Template Main JS File -->
                <script src="/asset/js/main.js"></script> 
                <br><br>
             
    </section>
   
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/employee/employeejobstatus/index.blade.php ENDPATH**/ ?>