
<?php $__env->startSection('content'); ?>
<div id="maincontainer">
  
  <!-- Recent Sales -->
    
            <section id="main" class="main" style="padding-top: 0vh;">
              <div class="pagetitle">
                  <h1>Department</h1>
                  <nav>
                  <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                      <li class="breadcrumb-item active"><a> Manage Department</a></li>
                  </ol>
                  </nav>
              </div>
              <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>      
  <div class="card recent-sales overflow-auto">
    
    <div class="filter">
      <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center">
          <!-- Dropdown Menu -->
          <!-- Search Bar -->
        </div>
      </div>
      
    </div>

    <div class="card-body">
      <table class="table table-borderless datatable">
        <thead>
          <tr>
          <th>ID</th>
          <th>Name</th>
          <th width="280px">Action</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($department->id); ?></td>
            <td><?php echo e($department->name); ?></td> 
            <td><span class="badge bg-succes">Action</span></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </tbody>
      </table>
    </div>
    <!-- End Recent Sales -->
    <div style="width: 100%;">
      <button class="buttonstyle" style="position: relative; left: 80%; bottom: 1vh;" type="button" id="buttooo12"
        aria-haspopup="true" aria-expanded="false">
        
      </button>
    </div>
    <div>
      <button class="buttonstyle" type="button" id="butto1" aria-haspopup="true" aria-expanded="false">
       <?php echo e($departments->links()); ?>

      </button>
      <button class="buttonstyle" style="position: relative; left: 60%;" type="button" id="buttooo133"
        aria-haspopup="true" aria-expanded="false">
        Previous
      </button>
      <button class="buttonstyle" style="position: relative; left: 60%;" type="button" id="buttooo13"
        aria-haspopup="true" aria-expanded="false">
        Next
      </button>

    </div>
  </div>


  <!-- Vendor JS Files -->
  

  <!-- Template Main JS File -->
  <script src="/asset/js/main.js"></script>
</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/department/index.blade.php ENDPATH**/ ?>