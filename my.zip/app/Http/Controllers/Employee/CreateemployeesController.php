<?php

namespace App\Http\Controllers\Employee;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CreateemployeesController extends Controller
{
    // this is our creayeemploye controller
    
}
