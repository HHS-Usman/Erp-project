<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Overtime_type_controller extends Controller
{
    
}
