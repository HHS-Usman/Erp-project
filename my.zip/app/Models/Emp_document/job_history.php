<?php

namespace App\Models\Emp_document;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class job_history extends Model
{
    use HasFactory;
}
